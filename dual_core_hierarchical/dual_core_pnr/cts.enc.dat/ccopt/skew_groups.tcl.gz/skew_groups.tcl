## Tcl for skew_group
# Skew Group Mode: all
switch_ccopt_skew_group_mode -create all
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin core2/clk 0.02
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin core2/clk 0.02
# Skew Group: all
create_ccopt_skew_group -name all -generated  -auto_sinks -sources {{clk rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
set_ccopt_property skew_group_insertion_delay -skew_group all -delay_corner WC -late -rise -pin core2/clk 0.02
# Skew Group Mode: default
switch_ccopt_skew_group_mode -create default
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin core2/clk 0.02
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin core2/clk 0.02
# Skew Group: clk/CON
create_ccopt_skew_group -name clk/CON -from_clock clk -from_constraint_modes {CON} -from_delay_corners {WC BC} -auto_sinks -sources {clk}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: fragment
switch_ccopt_skew_group_mode -create fragment
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin core2/clk 0.02
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin core2/clk 0.02
# Skew Group: 1
create_ccopt_skew_group -name 1 -generated  -fragment  -target_insertion_delay 0.576 -target_skew 0.051 -sinks {core2/clk sum_in_valid_core1_reg/CP sum_out_valid_core1_d_reg/CP sum_out_valid_core2_d_reg/CP sum_in_valid_core2_reg/CP core1/clk} -rank 0 -sources {{clk rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: icts
switch_ccopt_skew_group_mode -create icts
set_ccopt_property insertion_delay -delay_corner WC -late -rise -pin core2/clk 0.02
set_ccopt_property insertion_delay -delay_corner WC -late -fall -pin core2/clk 0.02
# Skew Group: clk/CON
create_ccopt_skew_group -name clk/CON -auto_sinks -sources {clk}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group

# Switch back to default mode.
switch_ccopt_skew_group_mode default